/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

public class MemoryGame {
    public static void main(String[] args) {
        // Start the Login screen
        Login.getInstance().setVisible(true);
    }
}
