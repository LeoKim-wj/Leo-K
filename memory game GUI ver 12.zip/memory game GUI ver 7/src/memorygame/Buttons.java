/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

import javax.swing.*;
import java.awt.*;

public class Buttons {
    public static ImageIcon changeImage(String filename) {
        ImageIcon icon = new ImageIcon("./" + filename);
        Image img = icon.getImage().getScaledInstance(120, 120, Image.SCALE_SMOOTH);
        return new ImageIcon(img);
    }
}
