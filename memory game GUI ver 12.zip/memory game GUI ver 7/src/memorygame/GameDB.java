/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */


import java.sql.*;

public class GameDB {
    private static final String DB_URL = "jdbc:derby:memorygameDB";  // Derby DB URL
    private static Connection connection;
           
    // database reset: create user table
    static {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            String createUserTable = "CREATE TABLE IF NOT EXISTS Users (" +
                                     "username VARCHAR(50) PRIMARY KEY, " +
                                     "password VARCHAR(50))";
            stmt.executeUpdate(createUserTable);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static boolean addUser(String username, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(
                     "INSERT INTO Users (username, password) VALUES (?, ?)")) {
            ps.setString(1, username);
            ps.setString(2, password);
            ps.executeUpdate();
            return true;
        } catch (SQLException e) {
            return false; // if the user already exist: false 
        }
    }

    public static boolean verifyUser(String username, String password) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement ps = conn.prepareStatement(
                     "SELECT * FROM Users WHERE username = ? AND password = ?")) {
            ps.setString(1, username);
            ps.setString(2, password);
            ResultSet rs = ps.executeQuery();
            return rs.next(); // if user already exist: true
        } catch (SQLException e) {
            e.printStackTrace();
            return false;
        }
    }

    public static void saveGame(int tryCount) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {

            String createTable = "CREATE TABLE IF NOT EXISTS GameResult (tries INT)";
            stmt.executeUpdate(createTable);

            String insertData = "INSERT INTO GameResult (tries) VALUES (" + tryCount + ")";
            stmt.executeUpdate(insertData);

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
}
