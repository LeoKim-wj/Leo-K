/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {
    public GameFrame(String title) {
        super(title);
        setLayout(new BorderLayout());
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GameLogic logic = new GameLogic(this); // gamelogic reset
        add(logic.getNorthPanel(), BorderLayout.NORTH);  // top panel
        add(logic.getCenterPanel(), BorderLayout.CENTER); // card panel

        pack();//no blank space around the panel
        setVisible(true);
    }

    private static GameFrame instance;

    public static GameFrame getInstance(String title) {
        if (instance == null) {
            instance = new GameFrame(title);
        }
        return instance;
    }
}
