/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
import java.util.Random;

public class GameLogic implements ActionListener {
    private JButton restartButton;
    private JLabel labelMessage;
    private JButton[] buttons = new JButton[16];
    private String[] images = { 
        "card (2).png", "card (3).png", "card (4).png", "card (5).png",
        "card (6).png", "card (7).png", "card (8).png", "card (9).png",
        "card (2).png", "card (3).png", "card (4).png", "card (5).png",
        "card (6).png", "card (7).png", "card (8).png", "card (9).png" 
    };
    private int openCount = 0, buttonIndexSave1, buttonIndexSave2;
    private int tryCount = 0, successCount = 0;
    private Timer timer;

    private JPanel panelNorth;
    private JPanel panelCenter;

    public GameLogic(JFrame frame) {
        initUI();
        mixCards();
    }

    private void initUI() {
        // top panel reset
        panelNorth = new JPanel();
        panelNorth.setLayout(new BoxLayout(panelNorth, BoxLayout.Y_AXIS));
        labelMessage = new JLabel("Find Same Cards! Try 0");
        labelMessage.setFont(new Font("Arial", Font.BOLD, 24));
        labelMessage.setAlignmentX(Component.CENTER_ALIGNMENT);

        restartButton = new JButton("Restart");
        restartButton.addActionListener(this);
        panelNorth.add(labelMessage);
        panelNorth.add(restartButton);

        // card placing panel reset
        panelCenter = new JPanel(new GridLayout(4, 4));
        for (int i = 0; i < 16; i++) {
            buttons[i] = new JButton();
            buttons[i].setIcon(Buttons.changeImage("card.png"));
            buttons[i].addActionListener(this);
            panelCenter.add(buttons[i]);
        }
    }

    public JPanel getNorthPanel() {
        return panelNorth;
    }

    public JPanel getCenterPanel() {
        return panelCenter;
    }

    private void mixCards() {
        Random rand = new Random();
        for (int i = 0; i < 1000; i++) {
            int r = rand.nextInt(15) + 1;
            String temp = images[0];
            images[0] = images[r];
            images[r] = temp;
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == restartButton) {
            restartGame();
            return;
        }

        if (openCount == 2) return;

        JButton btn = (JButton) e.getSource();
        int index = getButtonIndex(btn);
        btn.setIcon(Buttons.changeImage(images[index]));

        openCount++;
        if (openCount == 1) {
            buttonIndexSave1 = index;
        } else if (openCount == 2) {
            buttonIndexSave2 = index;
            tryCount++;
            labelMessage.setText("Find Same Card! Try " + tryCount);

            if (checkCards(buttonIndexSave1, buttonIndexSave2)) {
                openCount = 0;
                successCount++;
                if (successCount == 8) {
                    labelMessage.setText("Game Over! Try " + tryCount);
                    GameDB.saveGame(tryCount); // save to db
                }
            } else {
                backToCard();
            }
        }
    }

    private void restartGame() {
        openCount = 0;
        tryCount = 0;
        successCount = 0;
        labelMessage.setText("Find Same Cards! Try 0");
        mixCards();
        for (JButton button : buttons) {
            button.setIcon(Buttons.changeImage("card.png"));
        }
    }

    private void backToCard() {
        timer = new Timer(500, e -> {
            buttons[buttonIndexSave1].setIcon(Buttons.changeImage("card.png"));
            buttons[buttonIndexSave2].setIcon(Buttons.changeImage("card.png"));
            openCount = 0;
            timer.stop();
        });
        timer.start();
    }

    private boolean checkCards(int index1, int index2) {
        return index1 != index2 && images[index1].equals(images[index2]);
    }

    private int getButtonIndex(JButton btn) {
        for (int i = 0; i < 16; i++) {
            if (buttons[i] == btn) return i;
        }
        return -1;
    }
}
