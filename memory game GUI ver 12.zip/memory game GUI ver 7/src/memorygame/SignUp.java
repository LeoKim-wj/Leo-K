/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

class SignUp extends JFrame {
    private JTextField newUsernameField;
    private JPasswordField newPasswordField;
    private JButton signupButton;
    private JButton backButton;

    public SignUp() {
        setTitle("Sign up");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new GridLayout(3, 2));

        // UI Components
        newUsernameField = new JTextField();
        newPasswordField = new JPasswordField();
        signupButton = new JButton("Sign up");
        backButton = new JButton("Back to Login");

        // Adding components to the frame
        add(new JLabel("New Username:"));
        add(newUsernameField);
        add(new JLabel("New Password:"));
        add(newPasswordField);
        add(signupButton);
        add(backButton);

        backButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);  // Hide the signup frame
                Login.getInstance().setVisible(true);  // Show the login frame
            }
        });

        signupButton.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null, "Signup completed!");
            }
        });
    }

    // Singleton instance to prevent multiple windows
    private static SignUp instance;

    public static SignUp getInstance() {
        if (instance == null) {
            instance = new SignUp();
        }
        return instance;
    }
}