/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */

import javax.swing.*;
import java.awt.*;

public class GameFrame extends JFrame {
    public GameFrame(String title) {
        super(title);
        setLayout(new BorderLayout());
        setSize(600, 700);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        GameLogic logic = new GameLogic(this); // 게임 로직 초기화
        add(logic.getNorthPanel(), BorderLayout.NORTH);  // 상단 패널 추가
        add(logic.getCenterPanel(), BorderLayout.CENTER); // 카드 패널 추가

        pack(); // 빈 공간 최적화
        setVisible(true);
    }
}
