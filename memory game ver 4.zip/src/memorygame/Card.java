/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

import javax.swing.*;

/**
 *
 * @author kmkm3
 */
public class Card {
    private String imagePath;
    private boolean isMatched;

    public Card(String imagePath) {
        this.imagePath = imagePath;
        this.isMatched = false;
    }

    public String getImagePath() {
        return imagePath;
    }

    public void setMatched(boolean matched) {
        isMatched = matched;
    }

    public boolean isMatched() {
        return isMatched;
    }

    public ImageIcon getIcon() {
        return new ImageIcon("./" + imagePath);
    }
}