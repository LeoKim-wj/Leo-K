/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

/**
 *
 * @author kmkm3
 */
import java.sql.*;

public class GameDB {
    private static final String DB_URL = "jdbc:derby:memorygameDB;create=true";

    public static void saveGame(String[] images, int tryCount, int successCount, int timeRemaining) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement stmt = conn.prepareStatement(
                     "INSERT INTO game_state (card_images, try_count, success_count, time_remaining) VALUES (?, ?, ?, ?)")) {

            String cardState = String.join(",", images);
            stmt.setString(1, cardState);
            stmt.setInt(2, tryCount);
            stmt.setInt(3, successCount);
            stmt.setInt(4, timeRemaining);
            stmt.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public static String[] loadGame() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement();
             ResultSet rs = stmt.executeQuery("SELECT * FROM game_state ORDER BY ID DESC FETCH FIRST ROW ONLY")) {

            if (rs.next()) {
                return rs.getString("card_images").split(",");
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}