/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

import java.util.Random;
/**
 *
 * @author kmkm3
 */
public class GameLogic {
    private String[] images;
    private int tryCount = 0;
    private int successCount = 0;
    private int timeRemaining = 100;

    public GameLogic(String[] images) {
        this.images = images;
        shuffleCards();
    }

    public void shuffleCards() {
        Random rand = new Random();
        for (int i = 0; i < 1000; i++) {
            int random = rand.nextInt(images.length);
            String temp = images[0];
            images[0] = images[random];
            images[random] = temp;
        }
    }

    public boolean checkMatch(int index1, int index2) {
        return images[index1].equals(images[index2]);
    }

    public void incrementTryCount() {
        tryCount++;
    }

    public void incrementSuccessCount() {
        successCount++;
    }

    public boolean isGameOver() {
        return successCount == images.length / 2;
    }

    public int getTimeRemaining() {
        return timeRemaining;
    }

    public void decrementTime() {
        timeRemaining--;
    }

    public int getTryCount() {
        return tryCount;
    }
}