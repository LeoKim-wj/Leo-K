/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package memorygame;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
/**
 *
 * @author kmkm3
 */
public class GameUI extends JFrame implements ActionListener {
    private Card[] cards = new Card[16];
    private JButton[] buttons = new JButton[16];
    private GameLogic logic;
    private JLabel labelMessage;
    private Timer gameTimer;
    private int firstCardIndex = -1;

    public GameUI() {
        logic = new GameLogic(new String[]{
                "card (2).png", "card (3).png", "card (4).png", "card (5).png",
                "card (6).png", "card (7).png", "card (8).png", "card (9).png",
                "card (2).png", "card (3).png", "card (4).png", "card (5).png",
                "card (6).png", "card (7).png", "card (8).png", "card (9).png"
        });

        initUI();
        startGameTimer();
    }

    private void initUI() {
        setLayout(new BorderLayout());

        // 상단 패널 (메시지 및 버튼)
        JPanel panelNorth = new JPanel();
        labelMessage = new JLabel("Find Same Cards! Try 0");
        panelNorth.add(labelMessage);

        JButton restartButton = Buttons.createButton("Restart", this);
        JButton saveButton = Buttons.createButton("Save", this);
        JButton loadButton = Buttons.createButton("Load", this);

        panelNorth.add(restartButton);
        panelNorth.add(saveButton);
        panelNorth.add(loadButton);
        add(panelNorth, BorderLayout.NORTH);

        // 카드 배치
        JPanel panelCenter = new JPanel(new GridLayout(4, 4));
        for (int i = 0; i < 16; i++) {
            buttons[i] = new JButton(new ImageIcon("card.png"));
            buttons[i].addActionListener(this);
            panelCenter.add(buttons[i]);
        }
        add(panelCenter, BorderLayout.CENTER);

        setTitle("Memory Game");
        setSize(400, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setVisible(true);
    }

    private void startGameTimer() {
        gameTimer = new Timer(1000, e -> {
            logic.decrementTime();
            labelMessage.setText("Time: " + logic.getTimeRemaining() + "s");

            if (logic.getTimeRemaining() <= 0) {
                labelMessage.setText("Time's up! Game over.");
                gameTimer.stop();
            }
        });
        gameTimer.start();
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        JButton clickedButton = (JButton) e.getSource();
        int index = getButtonIndex(clickedButton);

        if (firstCardIndex == -1) {
            firstCardIndex = index;
        } else {
            logic.incrementTryCount();
            if (logic.checkMatch(firstCardIndex, index)) {
                logic.incrementSuccessCount();
                if (logic.isGameOver()) {
                    labelMessage.setText("You won! Try " + logic.getTryCount());
                    gameTimer.stop();
                }
            } else {
                resetCards(firstCardIndex, index);
            }
            firstCardIndex = -1;
        }
    }

    private int getButtonIndex(JButton btn) {
        for (int i = 0; i < buttons.length; i++) {
            if (buttons[i] == btn) return i;
        }
        return -1;
    }

    private void resetCards(int index1, int index2) {
        Timer resetTimer = new Timer(500, e -> {
            buttons[index1].setIcon(new ImageIcon("card.png"));
            buttons[index2].setIcon(new ImageIcon("card.png"));
            ((Timer) e.getSource()).stop();
        });
        resetTimer.start();
    }
}