package memorygame;

public class MemoryGame {
    public static void main(String[] args) {
        new GameUI(); 
    }
}